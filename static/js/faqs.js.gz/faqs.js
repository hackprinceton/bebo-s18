// In use when there is a two-column design.

// const $ = require('jquery');
// const jQueryBridget = require('jquery-bridget');
// const Masonry = require('masonry-layout');

// jQueryBridget('masonry', Masonry, $);

// $('.faq-wrap').masonry({
//   itemSelector: '.faq',
//   columnWidth: '.faq-sizer',
//   percentPosition: true,
// });

// $('.faq').on('on.zf.toggler off.zf.toggler', function() {
//   $('.faq-wrap').masonry();
// });